@echo off
start test.pdf
start Eventlog.exe
exit